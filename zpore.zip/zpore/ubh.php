<?php
/*
Plugin Name: SEO sadness
Description: Managing Seo

*/



?>